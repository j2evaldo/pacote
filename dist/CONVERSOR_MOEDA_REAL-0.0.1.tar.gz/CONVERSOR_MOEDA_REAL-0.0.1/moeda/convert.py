def converte(x):
    return f'R$ {x:.2f}'.replace('.', ',')